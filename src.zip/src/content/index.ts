console.info('[ext]gpt-page-token: content script loaded')
import { encode, isWithinTokenLimit } from 'gpt-tokenizer'

// Extract the page text
const text = document.body.textContent || ''

// Encode text into tokens
const tokens = encode(text)

// Create a div to display the token count
const div = document.createElement('div')
div.textContent = `Tokens: ${tokens.length}`
div.style.position = 'fixed'
div.style.right = '0px'
div.style.bottom = '0px'
div.style.padding = '10px'
div.style.backgroundColor = '#F9F9F9'
div.style.border = '1px solid #000'
div.style.zIndex = '10000'

// Append the div to the body of the webpage
document.body.appendChild(div)
